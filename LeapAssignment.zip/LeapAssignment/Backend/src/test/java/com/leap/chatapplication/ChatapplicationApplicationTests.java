package com.leap.chatapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
