package com.leap.chatapplication.Controller.Model;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
